#!/usr/bin/env python3
"""
Generates sample cape PNG files for CapeMaster testing.
Run this ONCE to create example capes in your .minecraft/capemaster/capes/ folder.

Usage:
    python3 generate_sample_capes.py [output_dir]

Default output: ./sample_capes/
"""

import os
import sys
import struct
import zlib

def write_png(filename, width, height, pixels):
    """pixels: list of (r,g,b,a) tuples, row-major"""
    def pack_chunk(name, data):
        c = zlib.crc32(name + data) & 0xFFFFFFFF
        return struct.pack('>I', len(data)) + name + data + struct.pack('>I', c)

    sig = b'\x89PNG\r\n\x1a\n'
    ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
    ihdr = pack_chunk(b'IHDR', ihdr_data)

    raw = b''
    for y in range(height):
        raw += b'\x00'  # filter type None
        for x in range(width):
            r, g, b, a = pixels[y * width + x]
            raw += bytes([r, g, b])

    compressed = zlib.compress(raw, 9)
    idat = pack_chunk(b'IDAT', compressed)
    iend = pack_chunk(b'IEND', b'')

    with open(filename, 'wb') as f:
        f.write(sig + ihdr + idat + iend)

def make_solid_cape(filename, color):
    """Simple solid-color cape: 64x32"""
    r, g, b = color
    pixels = []
    for y in range(32):
        for x in range(64):
            # Draw a border
            if x < 2 or x > 61 or y < 2 or y > 29:
                pixels.append((255, 255, 255, 255))
            else:
                # Add simple cross pattern
                if x == 32 or y == 16:
                    pixels.append((min(r+60,255), min(g+60,255), min(b+60,255), 255))
                else:
                    pixels.append((r, g, b, 255))
    write_png(filename, 64, 32, pixels)
    print(f"Created: {filename}")

def make_animated_cape(filename, colors, frame_height=64):
    """Animated cape: 64 x (frame_height * len(colors)) — vertical strip"""
    width = 64
    height = frame_height * len(colors)
    pixels = []

    for fi, (r, g, b) in enumerate(colors):
        for y in range(frame_height):
            for x in range(width):
                # Gradient effect per frame
                blend = y / frame_height
                pr = int(r * (1 - blend) + (255 - r) * blend * 0.3)
                pg = int(g * (1 - blend) + (255 - g) * blend * 0.3)
                pb = int(b * (1 - blend) + (255 - b) * blend * 0.3)

                # Shimmer line
                if y % 16 == fi % 16:
                    pr = min(pr + 80, 255)
                    pg = min(pg + 80, 255)
                    pb = min(pb + 80, 255)

                pixels.append((pr, pg, pb, 255))

    write_png(filename, width, height, pixels)
    print(f"Created animated: {filename} ({len(colors)} frames)")

if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else './sample_capes'
    os.makedirs(out, exist_ok=True)

    # Static capes
    make_solid_cape(os.path.join(out, 'cape_red.png'),    (180, 40,  40))
    make_solid_cape(os.path.join(out, 'cape_blue.png'),   (40,  80,  200))
    make_solid_cape(os.path.join(out, 'cape_green.png'),  (40,  160, 80))
    make_solid_cape(os.path.join(out, 'cape_purple.png'), (120, 40,  200))
    make_solid_cape(os.path.join(out, 'cape_gold.png'),   (220, 160, 20))

    # Animated capes (multi-frame vertical strips)
    make_animated_cape(os.path.join(out, 'cape_rainbow_anim.png'), [
        (220, 50,  50),
        (220, 140, 50),
        (200, 220, 50),
        (50,  200, 80),
        (50,  100, 220),
        (140, 50,  220),
        (220, 50,  180),
    ])

    make_animated_cape(os.path.join(out, 'cape_fire_anim.png'), [
        (255, 50,  10),
        (255, 90,  10),
        (255, 130, 20),
        (255, 80,  10),
        (200, 40,  10),
        (255, 60,  10),
    ])

    print(f"\nAll sample capes created in: {out}/")
    print("Place these in your .minecraft/capemaster/capes/ folder.")
    print("Then in-game, press O → Add Local Cape → enter the filename.")
