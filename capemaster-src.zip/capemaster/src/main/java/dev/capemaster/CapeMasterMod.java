package dev.capemaster;

import dev.capemaster.cape.CapeManager;
import dev.capemaster.gui.CapeMasterScreen;
import dev.capemaster.util.CapeConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CapeMasterMod implements ClientModInitializer {

    public static final String MOD_ID = "capemaster";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("CapeMaster initializing...");

        // Load config
        CapeConfig.load();

        // Initialize cape manager
        CapeManager.getInstance().initialize();

        // Register keybind (default: O)
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "capemaster.keybind.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_O,
                "CapeMaster"
        ));

        // Tick listener for keybind
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.player != null) {
                    client.setScreen(new CapeMasterScreen(null));
                }
            }
            // Tick animated capes
            CapeManager.getInstance().tick();
        });

        LOGGER.info("CapeMaster initialized! Press O to open the cape menu.");
    }
}
