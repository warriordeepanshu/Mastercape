package dev.capemaster.render;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages per-player CapeRenderer instances for smooth physics state.
 */
public class CapeRendererManager {

    private static final CapeRendererManager INSTANCE = new CapeRendererManager();
    public static CapeRendererManager getInstance() { return INSTANCE; }

    private final Map<UUID, CapeRenderer> renderers = new HashMap<>();

    private CapeRendererManager() {}

    public CapeRenderer getRenderer(PlayerEntity player) {
        return renderers.computeIfAbsent(player.getUuid(), k -> new CapeRenderer());
    }

    public void tickPlayer(PlayerEntity player) {
        getRenderer(player).tick(player);
    }

    public void cleanup(UUID playerId) {
        renderers.remove(playerId);
    }
}
