package dev.capemaster.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.capemaster.cape.CapeManager;
import dev.capemaster.util.CapeConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

/**
 * Handles the smooth physics-based cape rendering,
 * matching the quality of Lunar/Feather client capes.
 */
public class CapeRenderer {

    // Physics state
    private float capeBodyYawO = 0f;
    private float capeBodyYaw = 0f;
    private float capeFlap = 0f;
    private float capeFlapO = 0f;
    private float capeSideWay = 0f;
    private float capeSideWayO = 0f;

    // Per-instance sway targets
    private float targetFlap = 0f;
    private float targetSide = 0f;

    public void tick(PlayerEntity player) {
        capeFlapO = capeFlap;
        capeSideWayO = capeSideWay;
        capeBodyYawO = capeBodyYaw;

        float sway = CapeConfig.getSwayIntensity();

        // Physics simulation: cape lags behind body rotation
        float yawDelta = (float)(player.getBodyYaw() - capeBodyYaw);
        while (yawDelta > 180f) yawDelta -= 360f;
        while (yawDelta < -180f) yawDelta += 360f;

        capeBodyYaw += yawDelta * 0.1f;

        // Velocity-based flap
        double motionX = player.getX() - player.prevX;
        double motionZ = player.getZ() - player.prevZ;
        float speed = (float) Math.sqrt(motionX * motionX + motionZ * motionZ);

        // Sneak causes cape to droop forward
        if (player.isSneaking()) {
            targetFlap = Math.min(targetFlap + 0.05f, 0.4f * sway);
        } else {
            targetFlap = Math.max(targetFlap - 0.05f, 0f);
        }

        // Movement sways cape
        targetSide = (float) MathHelper.clamp(
                Math.atan2(motionX, motionZ) * speed * 4.0 * sway, -0.3, 0.3);

        capeFlap += (targetFlap - capeFlap) * 0.15f;
        capeSideWay += (targetSide - capeSideWay) * 0.15f;
    }

    /**
     * Renders the cape on a player entity.
     * Called from the PlayerEntityRenderer mixin.
     */
    public void renderCape(MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                           PlayerEntity player, float tickDelta, int light) {
        Identifier capeTexture = CapeManager.getInstance().getActiveCapeTexture();
        if (capeTexture == null) return;
        if (!CapeConfig.isShowOwnCape() &&
                player == MinecraftClient.getInstance().player) return;

        float smoothFlap = MathHelper.lerp(tickDelta, capeFlapO, capeFlap);
        float smoothSide = MathHelper.lerp(tickDelta, capeSideWayO, capeSideWay);
        float smoothYaw = MathHelper.lerp(tickDelta, capeBodyYawO, capeBodyYaw);

        matrices.push();

        // Position cape at the back of the neck
        matrices.translate(0.0, 0.0, 0.125);

        // Apply smooth rotation
        float yawOffset = (float) Math.toRadians(
                MathHelper.lerp(tickDelta, player.prevBodyYaw, player.bodyYaw) - smoothYaw
        );
        matrices.multiply(RotationAxis.POSITIVE_Y.rotation(yawOffset));

        // Sway side-to-side
        matrices.multiply(RotationAxis.POSITIVE_Z.rotation(smoothSide));

        // Flap forward/backward
        matrices.multiply(RotationAxis.POSITIVE_X.rotation(
                (float)(Math.PI + (Math.PI / 8.0) + smoothFlap)
        ));

        // Scale down to proper cape size
        matrices.scale(1.0f, 1.0f, 1.0f);

        float alpha = CapeConfig.getCapeOpacity();

        RenderLayer layer = RenderLayer.getEntityTranslucent(capeTexture);
        VertexConsumer consumer = vertexConsumers.getBuffer(layer);

        Matrix4f matrix = matrices.peek().getPositionMatrix();

        // Cape quad: 10x16 pixels, centered on attachment point
        float w = 0.625f; // 10/16
        float h = 1.0f;   // 16/16
        float u0 = 0f, u1 = 1f, v0 = 0f, v1 = 1f;

        // Draw back-face of the cape (visible from behind)
        drawCapeQuad(consumer, matrix, -w, 0f, 0f, w, -h, 0f, u0, u1, v0, v1, light, alpha);

        matrices.pop();
    }

    private void drawCapeQuad(VertexConsumer consumer, Matrix4f matrix,
                               float x0, float y0, float z0,
                               float x1, float y1, float z1,
                               float u0, float u1, float v0, float v1,
                               int light, float alpha) {
        int a = (int)(alpha * 255);

        // Top-left
        consumer.vertex(matrix, x0, y0, z0)
                .color(255, 255, 255, a)
                .texture(u0, v0)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(0f, 0f, 1f);

        // Bottom-left
        consumer.vertex(matrix, x0, y1, z1)
                .color(255, 255, 255, a)
                .texture(u0, v1)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(0f, 0f, 1f);

        // Bottom-right
        consumer.vertex(matrix, x1, y1, z1)
                .color(255, 255, 255, a)
                .texture(u1, v1)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(0f, 0f, 1f);

        // Top-right
        consumer.vertex(matrix, x1, y0, z0)
                .color(255, 255, 255, a)
                .texture(u1, v0)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(0f, 0f, 1f);
    }
}
