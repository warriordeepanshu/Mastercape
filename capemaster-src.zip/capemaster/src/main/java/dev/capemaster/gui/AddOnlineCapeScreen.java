package dev.capemaster.gui;

import dev.capemaster.cape.CapeEntry;
import dev.capemaster.cape.CapeManager;
import dev.capemaster.util.CapeConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.UUID;

public class AddOnlineCapeScreen extends Screen {

    private final Screen parent;
    private TextFieldWidget nameField;
    private TextFieldWidget urlField;
    private TextFieldWidget frameDelayField;
    private boolean animated = false;

    private String statusMessage = "";
    private int statusColor = 0xFFFFFF;

    private static final int PW = 320;
    private static final int PH = 220;
    private int px, py;

    public AddOnlineCapeScreen(Screen parent) {
        super(Text.translatable("capemaster.add_online.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        px = (width - PW) / 2;
        py = (height - PH) / 2;

        nameField = new TextFieldWidget(textRenderer, px + 10, py + 46, PW - 20, 18,
                Text.translatable("capemaster.add_online.name"));
        nameField.setMaxLength(64);
        nameField.setPlaceholderText(Text.literal("My Online Cape"));
        addDrawableChild(nameField);

        urlField = new TextFieldWidget(textRenderer, px + 10, py + 86, PW - 20, 18,
                Text.translatable("capemaster.add_online.url"));
        urlField.setMaxLength(1024);
        urlField.setPlaceholderText(Text.literal("https://example.com/cape.png"));
        addDrawableChild(urlField);

        // Animated toggle
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Animated: " + (animated ? "§aON" : "§cOFF")),
                btn -> {
                    animated = !animated;
                    clearChildren();
                    init();
                }
        ).dimensions(px + 10, py + 116, 120, 18).build());

        frameDelayField = new TextFieldWidget(textRenderer, px + 140, py + 116, 70, 18,
                Text.translatable("capemaster.add_local.frame_delay"));
        frameDelayField.setMaxLength(6);
        frameDelayField.setText("100");
        addDrawableChild(frameDelayField);

        addDrawableChild(ButtonWidget.builder(
                Text.translatable("capemaster.add_online.confirm"),
                btn -> addOnlineCape()
        ).dimensions(px + PW / 2 - 60, py + PH - 36, 120, 20).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("← Back"),
                btn -> client.setScreen(parent)
        ).dimensions(px + 6, py + PH - 36, 60, 20).build());
    }

    private void addOnlineCape() {
        String name = nameField.getText().trim();
        String url = urlField.getText().trim();

        if (name.isEmpty()) {
            statusMessage = "§cEnter a cape name.";
            return;
        }
        if (url.isEmpty() || (!url.startsWith("http://") && !url.startsWith("https://"))) {
            statusMessage = "§cEnter a valid http/https URL.";
            return;
        }

        int delay = 100;
        try { delay = Integer.parseInt(frameDelayField.getText().trim()); }
        catch (NumberFormatException ignored) {}

        CapeEntry entry = new CapeEntry(
                UUID.randomUUID().toString(),
                name,
                CapeEntry.SourceType.ONLINE,
                url,
                animated,
                Math.max(50, delay)
        );

        CapeConfig.addCape(entry);

        statusMessage = "§eDownloading cape... (may take a moment)";
        statusColor = 0xFFCC44;

        CapeManager.getInstance().loadCapeAsync(entry).thenAccept(success -> {
            if (success) {
                statusMessage = "§aCape fetched and cached for offline use!";
            } else {
                statusMessage = "§cFailed to fetch cape. Check URL or connection.";
            }
        });

        CapeManager.getInstance().setActiveCape(entry.getId());
        client.setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.fill(px, py, px + PW, py + PH, 0xE0101010);
        context.fill(px, py, px + PW, py + 4, 0xFF5B8CFF);

        context.drawTextWithShadow(textRenderer,
                Text.literal("✦ Add Online Cape"),
                px + 10, py + 10, 0x5B8CFF);

        context.drawTextWithShadow(textRenderer, Text.literal("Cape Name:"), px + 10, py + 36, 0xAAAAAA);
        context.drawTextWithShadow(textRenderer, Text.literal("Image URL (https://...):"), px + 10, py + 76, 0xAAAAAA);

        if (!statusMessage.isEmpty()) {
            context.drawCenteredTextWithShadow(textRenderer,
                    Text.literal(statusMessage), px + PW / 2, py + PH - 52, statusColor);
        }

        context.drawTextWithShadow(textRenderer,
                Text.literal("§7Online capes are cached locally for offline play."),
                px + 10, py + PH - 14, 0x444466);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
