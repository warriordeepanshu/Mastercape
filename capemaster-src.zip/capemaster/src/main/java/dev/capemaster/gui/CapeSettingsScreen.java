package dev.capemaster.gui;

import dev.capemaster.util.CapeConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public class CapeSettingsScreen extends Screen {

    private final Screen parent;
    private static final int PW = 300;
    private static final int PH = 230;
    private int px, py;

    public CapeSettingsScreen(Screen parent) {
        super(Text.translatable("capemaster.settings.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        px = (width - PW) / 2;
        py = (height - PH) / 2;

        int x = px + 10;
        int y = py + 36;
        int w = PW - 20;

        // Show own cape toggle
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Show Cape on Yourself: " +
                        (CapeConfig.isShowOwnCape() ? "§aON" : "§cOFF")),
                btn -> {
                    CapeConfig.setShowOwnCape(!CapeConfig.isShowOwnCape());
                    CapeConfig.save();
                    clearChildren(); init();
                }
        ).dimensions(x, y, w, 20).build());

        // Smooth animation toggle
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Smooth Animation: " +
                        (CapeConfig.isSmoothAnimation() ? "§aON" : "§cOFF")),
                btn -> {
                    CapeConfig.setSmoothAnimation(!CapeConfig.isSmoothAnimation());
                    CapeConfig.save();
                    clearChildren(); init();
                }
        ).dimensions(x, y + 26, w, 20).build());

        // Opacity slider
        addDrawableChild(new SliderWidget(x, y + 56, w, 20,
                Text.literal("Cape Opacity: " + (int)(CapeConfig.getCapeOpacity() * 100) + "%"),
                CapeConfig.getCapeOpacity()) {
            @Override
            protected void updateMessage() {
                setMessage(Text.literal("Cape Opacity: " + (int)(value * 100) + "%"));
            }
            @Override
            protected void applyValue() {
                CapeConfig.setCapeOpacity((float) value);
                CapeConfig.save();
            }
        });

        // Sway slider
        addDrawableChild(new SliderWidget(x, y + 82, w, 20,
                Text.literal("Sway Intensity: " + String.format("%.1f", CapeConfig.getSwayIntensity())),
                CapeConfig.getSwayIntensity() / 2.0) {
            @Override
            protected void updateMessage() {
                setMessage(Text.literal("Sway Intensity: " + String.format("%.1f", value * 2.0)));
            }
            @Override
            protected void applyValue() {
                CapeConfig.setSwayIntensity((float)(value * 2.0));
                CapeConfig.save();
            }
        });

        // Keybind hint
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Open Menu Key: O  (change in Controls)"),
                btn -> {}
        ).dimensions(x, y + 112, w, 18).build());

        // Reset defaults
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Reset to Defaults"),
                btn -> {
                    CapeConfig.setShowOwnCape(true);
                    CapeConfig.setSmoothAnimation(true);
                    CapeConfig.setCapeOpacity(1.0f);
                    CapeConfig.setSwayIntensity(1.0f);
                    CapeConfig.save();
                    clearChildren(); init();
                }
        ).dimensions(x, y + 140, w, 18).build());

        // Back
        addDrawableChild(ButtonWidget.builder(
                Text.literal("← Back"),
                btn -> client.setScreen(parent)
        ).dimensions(px + 6, py + PH - 28, 70, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.fill(px, py, px + PW, py + PH, 0xE0101010);
        context.fill(px, py, px + PW, py + 4, 0xFF5B8CFF);
        context.drawTextWithShadow(textRenderer,
                Text.literal("✦ CapeMaster Settings"),
                px + 10, py + 10, 0x5B8CFF);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
