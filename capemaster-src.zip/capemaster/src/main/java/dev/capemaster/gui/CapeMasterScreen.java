package dev.capemaster.gui;

import dev.capemaster.cape.CapeEntry;
import dev.capemaster.cape.CapeManager;
import dev.capemaster.util.CapeConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

/**
 * Main CapeMaster GUI — lists capes, lets you equip/delete,
 * and navigate to add/settings screens.
 */
public class CapeMasterScreen extends Screen {

    private static final int PANEL_WIDTH = 320;
    private static final int PANEL_HEIGHT = 260;
    private static final int ENTRY_HEIGHT = 28;

    private final Screen parent;
    private int panelX, panelY;

    // Scroll
    private int scrollOffset = 0;
    private static final int VISIBLE_ENTRIES = 6;

    public CapeMasterScreen(Screen parent) {
        super(Text.translatable("capemaster.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        panelX = (width - PANEL_WIDTH) / 2;
        panelY = (height - PANEL_HEIGHT) / 2;

        // Bottom buttons
        int btnY = panelY + PANEL_HEIGHT - 30;
        int btnW = 90;
        int gap = 6;
        int totalW = btnW * 3 + gap * 2;
        int startX = panelX + (PANEL_WIDTH - totalW) / 2;

        addDrawableChild(ButtonWidget.builder(
                Text.translatable("capemaster.menu.add_local"),
                btn -> client.setScreen(new AddLocalCapeScreen(this))
        ).dimensions(startX, btnY, btnW, 20).build());

        addDrawableChild(ButtonWidget.builder(
                Text.translatable("capemaster.menu.add_online"),
                btn -> client.setScreen(new AddOnlineCapeScreen(this))
        ).dimensions(startX + btnW + gap, btnY, btnW, 20).build());

        addDrawableChild(ButtonWidget.builder(
                Text.translatable("capemaster.menu.settings"),
                btn -> client.setScreen(new CapeSettingsScreen(this))
        ).dimensions(startX + (btnW + gap) * 2, btnY, btnW, 20).build());

        // Unequip button (top-right area)
        addDrawableChild(ButtonWidget.builder(
                Text.translatable("capemaster.menu.unequip"),
                btn -> {
                    CapeManager.getInstance().unequipCape();
                    clearAndInit();
                }
        ).dimensions(panelX + PANEL_WIDTH - 80, panelY + 8, 72, 16).build());

        buildCapeList();
    }

    private void buildCapeList() {
        List<CapeEntry> capes = CapeConfig.getCapes();
        int listX = panelX + 8;
        int listY = panelY + 36;

        int start = scrollOffset;
        int end = Math.min(start + VISIBLE_ENTRIES, capes.size());

        for (int i = start; i < end; i++) {
            CapeEntry entry = capes.get(i);
            int entryY = listY + (i - start) * ENTRY_HEIGHT;
            boolean isActive = entry.getId().equals(CapeConfig.getActiveCapeId());

            // Equip button
            addDrawableChild(ButtonWidget.builder(
                    Text.translatable(isActive ? "✔" : "capemaster.menu.select"),
                    btn -> {
                        if (isActive) {
                            CapeManager.getInstance().unequipCape();
                        } else {
                            CapeManager.getInstance().setActiveCape(entry.getId());
                            if (!CapeManager.getInstance().isCapeLoaded(entry.getId())) {
                                CapeManager.getInstance().loadCapeAsync(entry);
                            }
                        }
                        clearAndInit();
                    }
            ).dimensions(panelX + PANEL_WIDTH - 100, entryY + 4, 42, 18).build());

            // Delete button
            final int idx = i;
            addDrawableChild(ButtonWidget.builder(
                    Text.of("✗"),
                    btn -> {
                        CapeManager.getInstance().unloadCape(entry.getId());
                        CapeConfig.removeCape(entry.getId());
                        scrollOffset = Math.max(0, scrollOffset - 1);
                        clearAndInit();
                    }
            ).dimensions(panelX + PANEL_WIDTH - 54, entryY + 4, 18, 18)
                    .tooltip(Tooltip.of(Text.translatable("capemaster.menu.delete")))
                    .build());
        }

        // Scroll up/down
        if (capes.size() > VISIBLE_ENTRIES) {
            addDrawableChild(ButtonWidget.builder(Text.of("▲"),
                    btn -> { scrollOffset = Math.max(0, scrollOffset - 1); clearAndInit(); }
            ).dimensions(panelX + PANEL_WIDTH - 20, panelY + 36, 16, 14).build());

            addDrawableChild(ButtonWidget.builder(Text.of("▼"),
                    btn -> { scrollOffset = Math.min(capes.size() - VISIBLE_ENTRIES, scrollOffset + 1); clearAndInit(); }
            ).dimensions(panelX + PANEL_WIDTH - 20, panelY + 36 + VISIBLE_ENTRIES * ENTRY_HEIGHT - 14, 16, 14).build());
        }
    }

    private void clearAndInit() {
        clearChildren();
        init();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Background overlay
        renderBackground(context, mouseX, mouseY, delta);

        // Dark panel
        context.fill(panelX, panelY, panelX + PANEL_WIDTH, panelY + PANEL_HEIGHT, 0xE0101010);

        // Accent top bar
        context.fill(panelX, panelY, panelX + PANEL_WIDTH, panelY + 4, 0xFF5B8CFF);

        // Title
        context.drawTextWithShadow(textRenderer,
                Text.literal("✦ CapeMaster"),
                panelX + 10, panelY + 10, 0x5B8CFF);

        // Version tag
        context.drawTextWithShadow(textRenderer,
                Text.literal("v1.0"),
                panelX + PANEL_WIDTH - 90, panelY + 13, 0x888888);

        // Separator
        context.fill(panelX + 8, panelY + 28, panelX + PANEL_WIDTH - 8, panelY + 29, 0xFF333355);

        // Cape list
        List<CapeEntry> capes = CapeConfig.getCapes();
        if (capes.isEmpty()) {
            context.drawCenteredTextWithShadow(textRenderer,
                    Text.translatable("capemaster.menu.no_capes"),
                    panelX + PANEL_WIDTH / 2, panelY + 100, 0x666666);
        } else {
            int listX = panelX + 10;
            int listY = panelY + 36;
            int start = scrollOffset;
            int end = Math.min(start + VISIBLE_ENTRIES, capes.size());

            for (int i = start; i < end; i++) {
                CapeEntry entry = capes.get(i);
                int entryY = listY + (i - start) * ENTRY_HEIGHT;
                boolean isActive = entry.getId().equals(CapeConfig.getActiveCapeId());

                // Entry background
                int bgColor = isActive ? 0x40_5B8CFF : 0x30_FFFFFF;
                context.fill(panelX + 6, entryY, panelX + PANEL_WIDTH - 6, entryY + ENTRY_HEIGHT - 2, bgColor);

                // Cape name
                context.drawTextWithShadow(textRenderer,
                        Text.literal(entry.getName()),
                        listX + 4, entryY + 6, isActive ? 0xAAD4FF : 0xDDDDDD);

                // Type badge
                String badge = entry.getSourceType() == CapeEntry.SourceType.LOCAL ? "LOCAL" : "ONLINE";
                int badgeColor = entry.getSourceType() == CapeEntry.SourceType.LOCAL ? 0x88FF88 : 0xFFCC44;
                context.drawTextWithShadow(textRenderer,
                        Text.literal(badge),
                        listX + 4, entryY + 16, badgeColor);

                // Animated badge
                if (entry.isAnimated()) {
                    context.drawTextWithShadow(textRenderer,
                            Text.literal("✦ ANIM"),
                            listX + 50, entryY + 16, 0xFF88FF);
                }

                // Loaded indicator
                boolean loaded = CapeManager.getInstance().isCapeLoaded(entry.getId());
                context.drawTextWithShadow(textRenderer,
                        Text.literal(loaded ? "●" : "○"),
                        listX + 100, entryY + 16, loaded ? 0x55FF55 : 0xFF5555);
            }
        }

        // Bottom separator
        context.fill(panelX + 8, panelY + PANEL_HEIGHT - 34, panelX + PANEL_WIDTH - 8, panelY + PANEL_HEIGHT - 33, 0xFF222244);

        // Tip
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Press O to open this menu anytime"),
                panelX + PANEL_WIDTH / 2, panelY + PANEL_HEIGHT - 10, 0x444466);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount < 0) {
            scrollOffset = Math.min(Math.max(0, CapeConfig.getCapes().size() - VISIBLE_ENTRIES), scrollOffset + 1);
        } else {
            scrollOffset = Math.max(0, scrollOffset - 1);
        }
        clearAndInit();
        return true;
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }
}
