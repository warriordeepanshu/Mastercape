package dev.capemaster.gui;

import dev.capemaster.cape.CapeEntry;
import dev.capemaster.cape.CapeManager;
import dev.capemaster.util.CapeConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.io.File;
import java.util.UUID;

public class AddLocalCapeScreen extends Screen {

    private final Screen parent;
    private TextFieldWidget nameField;
    private TextFieldWidget pathField;
    private TextFieldWidget frameDelayField;
    private boolean animated = false;

    private String statusMessage = "";
    private int statusColor = 0xFFFFFF;

    private static final int PW = 300;
    private static final int PH = 220;
    private int px, py;

    public AddLocalCapeScreen(Screen parent) {
        super(Text.translatable("capemaster.add_local.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        px = (width - PW) / 2;
        py = (height - PH) / 2;

        // Name field
        nameField = new TextFieldWidget(textRenderer, px + 10, py + 46, PW - 20, 18,
                Text.translatable("capemaster.add_local.name"));
        nameField.setMaxLength(64);
        nameField.setPlaceholderText(Text.literal("My Cape"));
        addDrawableChild(nameField);

        // Path field
        pathField = new TextFieldWidget(textRenderer, px + 10, py + 86, PW - 20, 18,
                Text.translatable("capemaster.add_local.path"));
        pathField.setMaxLength(512);
        pathField.setPlaceholderText(Text.literal("C:/path/to/cape.png  or  relative/cape.png"));
        addDrawableChild(pathField);

        // Animated toggle
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Animated: " + (animated ? "§aON" : "§cOFF")),
                btn -> {
                    animated = !animated;
                    clearChildren();
                    init();
                }
        ).dimensions(px + 10, py + 116, 120, 18).build());

        // Frame delay field
        frameDelayField = new TextFieldWidget(textRenderer, px + 140, py + 116, 70, 18,
                Text.translatable("capemaster.add_local.frame_delay"));
        frameDelayField.setMaxLength(6);
        frameDelayField.setText("100");
        frameDelayField.setPlaceholderText(Text.literal("100 ms"));
        addDrawableChild(frameDelayField);

        // Confirm
        addDrawableChild(ButtonWidget.builder(
                Text.translatable("capemaster.add_local.confirm"),
                btn -> addCape()
        ).dimensions(px + (PW / 2) - 50, py + PH - 36, 100, 20).build());

        // Back
        addDrawableChild(ButtonWidget.builder(
                Text.literal("← Back"),
                btn -> client.setScreen(parent)
        ).dimensions(px + 6, py + PH - 36, 60, 20).build());
    }

    private void addCape() {
        String name = nameField.getText().trim();
        String path = pathField.getText().trim();

        if (name.isEmpty()) {
            statusMessage = "§cPlease enter a cape name.";
            return;
        }
        if (path.isEmpty()) {
            statusMessage = "§cPlease enter a file path.";
            return;
        }

        // Validate file exists
        File file = new File(path);
        if (!file.exists()) {
            // Try relative to capemaster/capes/
            File relative = CapeManager.getCapeStoragePath().resolve(path).toFile();
            if (!relative.exists()) {
                statusMessage = "§cFile not found: " + path;
                statusColor = 0xFF4444;
                return;
            }
        }

        int delay = 100;
        try { delay = Integer.parseInt(frameDelayField.getText().trim()); }
        catch (NumberFormatException ignored) {}

        CapeEntry entry = new CapeEntry(
                UUID.randomUUID().toString(),
                name,
                CapeEntry.SourceType.LOCAL,
                path,
                animated,
                Math.max(50, delay)
        );

        CapeConfig.addCape(entry);
        CapeManager.getInstance().loadCapeAsync(entry).thenAccept(success -> {
            if (success) {
                statusMessage = "§aCape added and loaded!";
                statusColor = 0x55FF55;
            } else {
                statusMessage = "§cAdded but failed to load texture. Check path.";
                statusColor = 0xFF5555;
            }
        });

        statusMessage = "§eLoading cape...";
        statusColor = 0xFFCC44;

        // Auto-equip
        CapeManager.getInstance().setActiveCape(entry.getId());
        client.setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);

        context.fill(px, py, px + PW, py + PH, 0xE0101010);
        context.fill(px, py, px + PW, py + 4, 0xFF5B8CFF);

        context.drawTextWithShadow(textRenderer,
                Text.literal("✦ Add Local Cape"),
                px + 10, py + 10, 0x5B8CFF);

        context.drawTextWithShadow(textRenderer,
                Text.literal("Cape Name:"), px + 10, py + 36, 0xAAAAAA);
        context.drawTextWithShadow(textRenderer,
                Text.literal("File Path (.png or animated multi-row .png):"), px + 10, py + 76, 0xAAAAAA);

        if (animated) {
            context.drawTextWithShadow(textRenderer,
                    Text.literal("Frame Delay (ms):"), px + 140, py + 106, 0xAAAAAA);
        }

        if (!statusMessage.isEmpty()) {
            context.drawCenteredTextWithShadow(textRenderer,
                    Text.literal(statusMessage),
                    px + PW / 2, py + PH - 52, statusColor);
        }

        // Hint
        context.drawTextWithShadow(textRenderer,
                Text.literal("§7Tip: Animated = vertical PNG strip (64×N px, each frame 64×64)"),
                px + 10, py + PH - 14, 0x444466);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
