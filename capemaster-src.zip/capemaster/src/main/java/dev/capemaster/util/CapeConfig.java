package dev.capemaster.util;

import com.google.gson.*;
import dev.capemaster.CapeMasterMod;
import dev.capemaster.cape.CapeEntry;
import net.minecraft.client.MinecraftClient;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Handles reading/writing the mod config to disk as JSON.
 * Config is stored at .minecraft/capemaster/config.json
 */
public class CapeConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static List<CapeEntry> capes = new ArrayList<>();
    private static String activeCapeId = null;

    // Settings
    private static boolean showOwnCape = true;
    private static boolean smoothAnimation = true;
    private static float capeOpacity = 1.0f;
    private static float swayIntensity = 1.0f;

    // ── Persistence ──────────────────────────────────────────────────────────

    public static Path getConfigPath() {
        return MinecraftClient.getInstance().runDirectory.toPath()
                .resolve("capemaster").resolve("config.json");
    }

    public static void load() {
        Path path = getConfigPath();
        if (!Files.exists(path)) {
            save();
            return;
        }
        try (Reader reader = Files.newBufferedReader(path)) {
            JsonObject root = GSON.fromJson(reader, JsonObject.class);
            if (root == null) return;

            activeCapeId = root.has("activeCapeId") && !root.get("activeCapeId").isJsonNull()
                    ? root.get("activeCapeId").getAsString() : null;
            showOwnCape = root.has("showOwnCape") && root.get("showOwnCape").getAsBoolean();
            smoothAnimation = !root.has("smoothAnimation") || root.get("smoothAnimation").getAsBoolean();
            capeOpacity = root.has("capeOpacity") ? root.get("capeOpacity").getAsFloat() : 1.0f;
            swayIntensity = root.has("swayIntensity") ? root.get("swayIntensity").getAsFloat() : 1.0f;

            capes.clear();
            if (root.has("capes") && root.get("capes").isJsonArray()) {
                JsonArray arr = root.getAsJsonArray("capes");
                for (JsonElement el : arr) {
                    try {
                        JsonObject obj = el.getAsJsonObject();
                        CapeEntry entry = new CapeEntry();
                        entry.setId(obj.get("id").getAsString());
                        entry.setName(obj.get("name").getAsString());
                        entry.setSourceType(CapeEntry.SourceType.valueOf(obj.get("sourceType").getAsString()));
                        entry.setSource(obj.get("source").getAsString());
                        entry.setAnimated(obj.has("animated") && obj.get("animated").getAsBoolean());
                        entry.setFrameDelay(obj.has("frameDelay") ? obj.get("frameDelay").getAsInt() : 100);
                        capes.add(entry);
                    } catch (Exception e) {
                        CapeMasterMod.LOGGER.error("Failed to load a cape entry: {}", e.getMessage());
                    }
                }
            }
            CapeMasterMod.LOGGER.info("CapeMaster config loaded. {} cape(s).", capes.size());
        } catch (Exception e) {
            CapeMasterMod.LOGGER.error("Error loading CapeMaster config: {}", e.getMessage());
        }
    }

    public static void save() {
        try {
            Path path = getConfigPath();
            Files.createDirectories(path.getParent());

            JsonObject root = new JsonObject();
            root.addProperty("activeCapeId", activeCapeId);
            root.addProperty("showOwnCape", showOwnCape);
            root.addProperty("smoothAnimation", smoothAnimation);
            root.addProperty("capeOpacity", capeOpacity);
            root.addProperty("swayIntensity", swayIntensity);

            JsonArray arr = new JsonArray();
            for (CapeEntry entry : capes) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id", entry.getId());
                obj.addProperty("name", entry.getName());
                obj.addProperty("sourceType", entry.getSourceType().name());
                obj.addProperty("source", entry.getSource());
                obj.addProperty("animated", entry.isAnimated());
                obj.addProperty("frameDelay", entry.getFrameDelay());
                arr.add(obj);
            }
            root.add("capes", arr);

            try (Writer writer = Files.newBufferedWriter(path)) {
                GSON.toJson(root, writer);
            }
        } catch (Exception e) {
            CapeMasterMod.LOGGER.error("Error saving CapeMaster config: {}", e.getMessage());
        }
    }

    // ── Cape List ────────────────────────────────────────────────────────────

    public static List<CapeEntry> getCapes() { return Collections.unmodifiableList(capes); }

    public static CapeEntry getCapeById(String id) {
        for (CapeEntry e : capes) if (e.getId().equals(id)) return e;
        return null;
    }

    public static void addCape(CapeEntry entry) {
        capes.add(entry);
        save();
    }

    public static void removeCape(String id) {
        capes.removeIf(e -> e.getId().equals(id));
        if (id.equals(activeCapeId)) activeCapeId = null;
        save();
    }

    // ── Getters / Setters ────────────────────────────────────────────────────

    public static String getActiveCapeId() { return activeCapeId; }
    public static void setActiveCapeId(String id) { activeCapeId = id; }

    public static boolean isShowOwnCape() { return showOwnCape; }
    public static void setShowOwnCape(boolean v) { showOwnCape = v; }

    public static boolean isSmoothAnimation() { return smoothAnimation; }
    public static void setSmoothAnimation(boolean v) { smoothAnimation = v; }

    public static float getCapeOpacity() { return capeOpacity; }
    public static void setCapeOpacity(float v) { capeOpacity = Math.max(0f, Math.min(1f, v)); }

    public static float getSwayIntensity() { return swayIntensity; }
    public static void setSwayIntensity(float v) { swayIntensity = Math.max(0f, Math.min(2f, v)); }
}
