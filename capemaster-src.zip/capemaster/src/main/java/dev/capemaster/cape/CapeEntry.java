package dev.capemaster.cape;

/**
 * Represents a single cape entry (local file or online URL).
 */
public class CapeEntry {

    public enum SourceType {
        LOCAL,
        ONLINE
    }

    private String id;          // Unique UUID string
    private String name;        // Display name
    private SourceType sourceType;
    private String source;      // File path or URL
    private boolean animated;   // Multi-frame animated cape
    private int frameDelay;     // Ms per frame (animated only)
    private int frameCount;     // Detected frame count
    private int frameWidth;     // Width of each frame
    private int frameHeight;    // Height of each frame

    public CapeEntry() {}

    public CapeEntry(String id, String name, SourceType sourceType, String source,
                     boolean animated, int frameDelay) {
        this.id = id;
        this.name = name;
        this.sourceType = sourceType;
        this.source = source;
        this.animated = animated;
        this.frameDelay = frameDelay;
        this.frameCount = 1;
    }

    // ── Getters ──────────────────────────────────────────────────────────────

    public String getId() { return id; }
    public String getName() { return name; }
    public SourceType getSourceType() { return sourceType; }
    public String getSource() { return source; }
    public boolean isAnimated() { return animated; }
    public int getFrameDelay() { return frameDelay; }
    public int getFrameCount() { return frameCount; }
    public int getFrameWidth() { return frameWidth; }
    public int getFrameHeight() { return frameHeight; }

    // ── Setters ──────────────────────────────────────────────────────────────

    public void setId(String id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setSourceType(SourceType sourceType) { this.sourceType = sourceType; }
    public void setSource(String source) { this.source = source; }
    public void setAnimated(boolean animated) { this.animated = animated; }
    public void setFrameDelay(int frameDelay) { this.frameDelay = frameDelay; }
    public void setFrameCount(int frameCount) { this.frameCount = frameCount; }
    public void setFrameWidth(int frameWidth) { this.frameWidth = frameWidth; }
    public void setFrameHeight(int frameHeight) { this.frameHeight = frameHeight; }
}
