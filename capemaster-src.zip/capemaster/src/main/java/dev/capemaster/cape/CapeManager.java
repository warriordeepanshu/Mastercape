package dev.capemaster.cape;

import dev.capemaster.CapeMasterMod;
import dev.capemaster.util.CapeConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages all capes: loading, texture registration, animation ticking.
 * Designed for smoothness comparable to Lunar/Feather clients.
 */
public class CapeManager {

    private static final CapeManager INSTANCE = new CapeManager();
    public static CapeManager getInstance() { return INSTANCE; }

    // registered cape textures: capeId -> Identifier
    private final Map<String, Identifier> capeTextures = new ConcurrentHashMap<>();

    // animation state: capeId -> current frame index
    private final Map<String, Integer> animationFrames = new ConcurrentHashMap<>();

    // animation timers: capeId -> ms since last frame change
    private final Map<String, Long> animationTimers = new ConcurrentHashMap<>();

    // for multi-frame capes we store per-frame identifiers
    // capeId -> list of per-frame Identifiers
    private final Map<String, List<Identifier>> frameTextures = new ConcurrentHashMap<>();

    // track which capes are loading so we don't double-load
    private final Set<String> loadingCapes = Collections.synchronizedSet(new HashSet<>());

    // http client for online capes
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    private String activeCapeId = null;

    private CapeManager() {}

    public void initialize() {
        activeCapeId = CapeConfig.getActiveCapeId();
        // Pre-load the active cape if set
        if (activeCapeId != null) {
            CapeEntry entry = CapeConfig.getCapeById(activeCapeId);
            if (entry != null) {
                loadCapeAsync(entry);
            }
        }
    }

    // ── Public API ───────────────────────────────────────────────────────────

    public String getActiveCapeId() { return activeCapeId; }

    public void setActiveCape(String id) {
        this.activeCapeId = id;
        CapeConfig.setActiveCapeId(id);
        CapeConfig.save();

        if (id != null) {
            CapeEntry entry = CapeConfig.getCapeById(id);
            if (entry != null && !capeTextures.containsKey(id)) {
                loadCapeAsync(entry);
            }
        }
    }

    public void unequipCape() {
        setActiveCape(null);
    }

    public boolean isCapeLoaded(String id) {
        return capeTextures.containsKey(id);
    }

    /**
     * Returns the current texture identifier for the active cape,
     * accounting for animation. Returns null if no cape is active.
     */
    public Identifier getActiveCapeTexture() {
        if (activeCapeId == null) return null;
        return getCurrentTexture(activeCapeId);
    }

    public Identifier getCurrentTexture(String id) {
        List<Identifier> frames = frameTextures.get(id);
        if (frames == null || frames.isEmpty()) {
            return capeTextures.get(id);
        }
        int frame = animationFrames.getOrDefault(id, 0);
        if (frame < frames.size()) {
            return frames.get(frame);
        }
        return frames.get(0);
    }

    /**
     * Tick called every client tick for animation advancement.
     * Uses system time for smooth, tick-rate-independent animation.
     */
    public void tick() {
        long now = System.currentTimeMillis();
        for (String id : frameTextures.keySet()) {
            CapeEntry entry = CapeConfig.getCapeById(id);
            if (entry == null) continue;

            List<Identifier> frames = frameTextures.get(id);
            if (frames == null || frames.size() <= 1) continue;

            long lastTick = animationTimers.getOrDefault(id, now);
            long elapsed = now - lastTick;

            int delay = Math.max(50, entry.getFrameDelay());
            if (elapsed >= delay) {
                int current = animationFrames.getOrDefault(id, 0);
                animationFrames.put(id, (current + 1) % frames.size());
                animationTimers.put(id, now);
            }
        }
    }

    // ── Loading ───────────────────────────────────────────────────────────────

    public CompletableFuture<Boolean> loadCapeAsync(CapeEntry entry) {
        if (loadingCapes.contains(entry.getId())) {
            return CompletableFuture.completedFuture(false);
        }
        loadingCapes.add(entry.getId());

        return CompletableFuture.supplyAsync(() -> {
            try {
                byte[] imageData = fetchImageBytes(entry);
                if (imageData == null) {
                    CapeMasterMod.LOGGER.error("Failed to fetch cape image for: {}", entry.getName());
                    return false;
                }

                // Slice frames on a background thread
                List<BufferedImage> frames = sliceFrames(entry, imageData);
                if (frames.isEmpty()) return false;

                entry.setFrameCount(frames.size());

                // Must register textures on the render thread
                List<BufferedImage> finalFrames = frames;
                MinecraftClient.getInstance().execute(() -> {
                    registerFrameTextures(entry, finalFrames);
                    loadingCapes.remove(entry.getId());
                });

                return true;
            } catch (Exception e) {
                CapeMasterMod.LOGGER.error("Error loading cape '{}': {}", entry.getName(), e.getMessage());
                loadingCapes.remove(entry.getId());
                return false;
            }
        });
    }

    private byte[] fetchImageBytes(CapeEntry entry) throws Exception {
        if (entry.getSourceType() == CapeEntry.SourceType.LOCAL) {
            File file = new File(entry.getSource());
            if (!file.exists()) {
                // Try relative to config dir
                Path configPath = getCapeStoragePath().resolve(entry.getSource());
                if (Files.exists(configPath)) {
                    return Files.readAllBytes(configPath);
                }
                CapeMasterMod.LOGGER.error("Local cape file not found: {}", entry.getSource());
                return null;
            }
            return Files.readAllBytes(file.toPath());
        } else {
            // Online — check cache first
            Path cachedFile = getCacheFilePath(entry.getId());
            if (Files.exists(cachedFile)) {
                return Files.readAllBytes(cachedFile);
            }

            // Download
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(entry.getSource()))
                    .timeout(Duration.ofSeconds(15))
                    .GET()
                    .build();

            HttpResponse<byte[]> response = httpClient.send(request, HttpResponse.BodyHandlers.ofByteArray());
            if (response.statusCode() == 200) {
                byte[] data = response.body();
                // Cache for offline use
                Files.createDirectories(cachedFile.getParent());
                Files.write(cachedFile, data);
                return data;
            }
            CapeMasterMod.LOGGER.error("HTTP {} fetching cape: {}", response.statusCode(), entry.getSource());
            return null;
        }
    }

    /**
     * Slices a vertically-stacked sprite sheet into individual frames.
     * For a standard cape: width=64, each frame height=32.
     * If image height > 32, treat as animated (multiple frames stacked vertically).
     */
    private List<BufferedImage> sliceFrames(CapeEntry entry, byte[] data) throws IOException {
        List<BufferedImage> frames = new ArrayList<>();

        BufferedImage full = ImageIO.read(new ByteArrayInputStream(data));
        if (full == null) {
            CapeMasterMod.LOGGER.error("Cannot read image data for cape: {}", entry.getName());
            return frames;
        }

        int w = full.getWidth();
        int h = full.getHeight();

        if (entry.isAnimated() && h > w) {
            // Vertical strip: each frame is w x w
            int frameH = w; // square frames
            int count = h / frameH;
            if (count < 1) count = 1;
            entry.setFrameWidth(w);
            entry.setFrameHeight(frameH);
            for (int i = 0; i < count; i++) {
                BufferedImage frame = full.getSubimage(0, i * frameH, w, Math.min(frameH, h - i * frameH));
                frames.add(frame);
            }
        } else {
            entry.setFrameWidth(w);
            entry.setFrameHeight(h);
            frames.add(full);
        }

        return frames;
    }

    private void registerFrameTextures(CapeEntry entry, List<BufferedImage> frames) {
        MinecraftClient client = MinecraftClient.getInstance();

        List<Identifier> ids = new ArrayList<>();
        for (int i = 0; i < frames.size(); i++) {
            Identifier id = Identifier.of(CapeMasterMod.MOD_ID,
                    "cape/" + entry.getId().replace("-", "") + "_f" + i);
            try {
                NativeImage nativeImage = bufferedImageToNative(frames.get(i));
                NativeImageBackedTexture texture = new NativeImageBackedTexture(nativeImage);
                client.getTextureManager().registerTexture(id, texture);
                ids.add(id);
            } catch (Exception e) {
                CapeMasterMod.LOGGER.error("Failed to register frame {} for cape {}: {}", i, entry.getName(), e.getMessage());
            }
        }

        if (!ids.isEmpty()) {
            frameTextures.put(entry.getId(), ids);
            capeTextures.put(entry.getId(), ids.get(0));
            animationFrames.put(entry.getId(), 0);
            animationTimers.put(entry.getId(), System.currentTimeMillis());
            CapeMasterMod.LOGGER.info("Cape '{}' loaded with {} frame(s)", entry.getName(), ids.size());
        }
    }

    private NativeImage bufferedImageToNative(BufferedImage img) throws IOException {
        int w = img.getWidth();
        int h = img.getHeight();
        NativeImage native_ = new NativeImage(w, h, false);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int argb = img.getRGB(x, y);
                // NativeImage uses ABGR, Minecraft uses ARGB
                int a = (argb >> 24) & 0xFF;
                int r = (argb >> 16) & 0xFF;
                int g = (argb >> 8) & 0xFF;
                int b = argb & 0xFF;
                int abgr = (a << 24) | (b << 16) | (g << 8) | r;
                native_.setColor(x, y, abgr);
            }
        }
        return native_;
    }

    // ── Paths ─────────────────────────────────────────────────────────────────

    public static Path getCapeStoragePath() {
        Path dir = MinecraftClient.getInstance().runDirectory.toPath()
                .resolve("capemaster").resolve("capes");
        try { Files.createDirectories(dir); } catch (IOException ignored) {}
        return dir;
    }

    public static Path getCacheFilePath(String id) {
        return MinecraftClient.getInstance().runDirectory.toPath()
                .resolve("capemaster").resolve("cache").resolve(id + ".png");
    }

    // ── Cleanup ───────────────────────────────────────────────────────────────

    public void unloadCape(String id) {
        capeTextures.remove(id);
        frameTextures.remove(id);
        animationFrames.remove(id);
        animationTimers.remove(id);
    }
}
