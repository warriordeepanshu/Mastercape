package dev.capemaster.mixin;

import dev.capemaster.cape.CapeManager;
import dev.capemaster.render.CapeRenderer;
import dev.capemaster.render.CapeRendererManager;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public class PlayerEntityRendererMixin {

    /**
     * Inject after the vanilla cape render to overlay our custom cape.
     * We inject at TAIL of the render method to ensure we draw on top.
     */
    @Inject(
            method = "render(Lnet/minecraft/client/network/AbstractClientPlayerEntity;" +
                    "FFLnet/minecraft/client/util/math/MatrixStack;" +
                    "Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("TAIL")
    )
    private void onRender(AbstractClientPlayerEntity player, float yaw, float tickDelta,
                          MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                          int light, CallbackInfo ci) {

        // Only render if a cape is active
        if (CapeManager.getInstance().getActiveCapeId() == null) return;
        if (!CapeManager.getInstance().isCapeLoaded(CapeManager.getInstance().getActiveCapeId())) return;

        CapeRenderer renderer = CapeRendererManager.getInstance().getRenderer(player);

        matrices.push();

        // The player renderer positions at feet. Cape attaches at upper back.
        // Move to shoulder-level attachment point.
        matrices.translate(0.0, 1.5, 0.0);

        renderer.renderCape(matrices, vertexConsumers, player, tickDelta, light);

        matrices.pop();
    }

    /**
     * Tick physics every render frame for smooth interpolation.
     */
    @Inject(
            method = "render(Lnet/minecraft/client/network/AbstractClientPlayerEntity;" +
                    "FFLnet/minecraft/client/util/math/MatrixStack;" +
                    "Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD")
    )
    private void onRenderHead(AbstractClientPlayerEntity player, float yaw, float tickDelta,
                              MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                              int light, CallbackInfo ci) {
        CapeRendererManager.getInstance().tickPlayer(player);
    }
}
