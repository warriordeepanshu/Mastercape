package dev.capemaster.mixin;

import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Placeholder mixin for GameRenderer hooks if needed in future.
 */
@Mixin(GameRenderer.class)
public class GameRendererMixin {
    // Reserved for future global render hooks
}
