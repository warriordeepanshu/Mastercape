package dev.capemaster.network;

import dev.capemaster.CapeMasterMod;
import dev.capemaster.cape.CapeManager;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

/**
 * Utility for downloading cape images from URLs with caching.
 * Online capes are cached to disk so they work offline.
 */
public class CapeDownloader {

    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    /**
     * Downloads a cape image from the given URL.
     * Returns cached bytes if available (offline support).
     */
    public static CompletableFuture<byte[]> download(String url, String capeId) {
        Path cache = CapeManager.getCacheFilePath(capeId);

        // Serve from cache if offline or already downloaded
        if (Files.exists(cache)) {
            return CompletableFuture.supplyAsync(() -> {
                try {
                    CapeMasterMod.LOGGER.info("Serving cape {} from cache.", capeId);
                    return Files.readAllBytes(cache);
                } catch (Exception e) {
                    CapeMasterMod.LOGGER.error("Cache read failed: {}", e.getMessage());
                    return null;
                }
            });
        }

        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .timeout(Duration.ofSeconds(20))
                        .header("User-Agent", "CapeMaster-Mod/1.0")
                        .GET()
                        .build();

                HttpResponse<byte[]> response = CLIENT.send(request,
                        HttpResponse.BodyHandlers.ofByteArray());

                if (response.statusCode() == 200) {
                    byte[] data = response.body();
                    // Save to cache
                    try {
                        Files.createDirectories(cache.getParent());
                        Files.write(cache, data);
                        CapeMasterMod.LOGGER.info("Cape {} cached to disk ({} bytes)", capeId, data.length);
                    } catch (Exception e) {
                        CapeMasterMod.LOGGER.warn("Could not cache cape {}: {}", capeId, e.getMessage());
                    }
                    return data;
                } else {
                    CapeMasterMod.LOGGER.error("HTTP {} fetching cape from {}", response.statusCode(), url);
                    return null;
                }
            } catch (Exception e) {
                CapeMasterMod.LOGGER.error("Download failed for {}: {}", url, e.getMessage());
                // Try cache as fallback
                if (Files.exists(cache)) {
                    try {
                        CapeMasterMod.LOGGER.info("Network down — using stale cache for {}", capeId);
                        return Files.readAllBytes(cache);
                    } catch (Exception ignored) {}
                }
                return null;
            }
        });
    }

    /**
     * Clears the cached file for a given cape ID.
     */
    public static void clearCache(String capeId) {
        try {
            Path cache = CapeManager.getCacheFilePath(capeId);
            Files.deleteIfExists(cache);
        } catch (Exception e) {
            CapeMasterMod.LOGGER.warn("Could not clear cache for {}: {}", capeId, e.getMessage());
        }
    }
}
