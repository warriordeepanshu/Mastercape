# CapeMaster — Custom Capes for Minecraft 1.21.1 (Fabric)

> Client-side custom capes with smooth physics, animation support, online/offline caching, and a sleek in-game menu.  
> Works like Feather/Lunar client capes — but open-source and drop-in.

---

## ✨ Features

| Feature | Details |
|---|---|
| **Local Capes** | Point to any `.png` on your disk |
| **Online Capes** | Paste a URL — auto-downloaded & cached offline |
| **Animated Capes** | Vertical PNG strip (64×64 per frame) — plays smoothly |
| **Physics Sway** | Real momentum-based flap & side-sway like Feather/Lunar |
| **Opacity Control** | Slider from 0–100% |
| **Offline Mode** | Online capes cached locally — works without internet |
| **In-game Menu** | Full GUI — no config file editing needed |
| **Keybind** | Default `O` key — rebindable in Controls |
| **No server needed** | Pure client-side, works on any server |

---

## 📦 Installation

### Requirements
- Minecraft **1.21.1** (Java Edition)
- [Fabric Loader](https://fabricmc.net/use/installer/) **≥ 0.16.5**
- [Fabric API](https://modrinth.com/mod/fabric-api) **0.102.0+1.21.1**

### Steps
1. Install Fabric Loader for 1.21.1
2. Download `fabric-api-0.102.0+1.21.1.jar` → put in `.minecraft/mods/`
3. Put `capemaster-1.0.0.jar` into `.minecraft/mods/`
4. Launch Minecraft → press **O** in-game to open the menu

---

## 🏗️ Building from Source

### Prerequisites
- JDK 21
- Gradle 8.8+

```bash
git clone <this-repo>
cd capemaster

# Generate Gradle wrapper first (one-time)
gradle wrapper --gradle-version 8.8

# Build the mod JAR
./gradlew build
```

The built JAR will be at:
```
build/libs/capemaster-1.0.0.jar
```

Drop that JAR into your `.minecraft/mods/` folder.

---

## 🎨 Using CapeMaster In-Game

### Opening the Menu
Press **O** (default) or rebind in: `Options → Controls → CapeMaster`

### Adding a Local Cape
1. Press **O** → **Add Local Cape**
2. Enter a name
3. Enter the full path to your `.png` file  
   _Example: `C:\Users\You\Downloads\mycape.png`_
4. For animated capes: toggle **Animated ON** and set frame delay
5. Click **Add Cape** — it auto-equips

**Shortcut:** Drop your PNG into:
```
.minecraft/capemaster/capes/
```
Then just type the filename (e.g. `mycape.png`) instead of the full path.

### Adding an Online Cape
1. Press **O** → **Add Online Cape**
2. Enter a name and a direct image URL (must end in `.png`)
3. Click **Fetch & Add** — downloads and caches for offline use

### Animated Cape Format
Your PNG should be a **vertical strip**:
- Width: `64px`
- Height: `64px × number_of_frames`
- Frame order: top = frame 1, bottom = last frame

```
┌─────────┐  ← Frame 1 (64×64)
│         │
├─────────┤  ← Frame 2
│         │
├─────────┤  ← Frame 3
│   ...   │
└─────────┘
```

### Settings
- **Show Cape on Yourself** — toggle visibility in first/third person
- **Smooth Animation** — enable interpolated physics
- **Cape Opacity** — 0–100%
- **Sway Intensity** — how much the cape flaps (0–2×)

---

## 📁 File Structure (In Your .minecraft Folder)

```
.minecraft/
└── capemaster/
    ├── config.json          ← all settings & cape list
    ├── capes/               ← drop local cape PNGs here
    └── cache/               ← auto-cached online capes (offline support)
```

---

## 🖼️ Making Your Own Animated Cape (Photoshop / GIMP)

1. Create a new image: **64 wide × (64 × frame count) tall**  
   e.g. 8 frames = `64 × 512`
2. Draw each frame in its 64×64 slot (top to bottom)
3. Export as `.png`
4. In CapeMaster: Add Local Cape → **Animated ON** → set frame delay (e.g. 80ms = ~12fps)

---

## 🌐 Online Cape Sources

You can use any direct PNG URL. Some options:
- Host on [Imgur](https://imgur.com) (right-click image → Copy image address)
- Use [GitHub raw URLs](https://raw.githubusercontent.com/...)
- Self-host on any static file server

**Important:** The URL must be a direct link to a `.png` image, not a webpage.

---

## ⚙️ config.json Reference

Located at `.minecraft/capemaster/config.json` — edited automatically by the GUI.

```json
{
  "activeCapeId": "uuid-of-active-cape",
  "showOwnCape": true,
  "smoothAnimation": true,
  "capeOpacity": 1.0,
  "swayIntensity": 1.0,
  "capes": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "name": "My Red Cape",
      "sourceType": "LOCAL",
      "source": "cape_red.png",
      "animated": false,
      "frameDelay": 100
    },
    {
      "id": "550e8400-e29b-41d4-a716-446655440001",
      "name": "Rainbow Animated",
      "sourceType": "ONLINE",
      "source": "https://example.com/rainbow_cape.png",
      "animated": true,
      "frameDelay": 80
    }
  ]
}
```

---

## 🔧 Mod Structure (For Developers)

```
src/main/java/dev/capemaster/
├── CapeMasterMod.java          ← Entrypoint, keybind registration
├── cape/
│   ├── CapeEntry.java          ← Data model (id, name, source, animation)
│   └── CapeManager.java        ← Texture loading, animation ticking
├── gui/
│   ├── CapeMasterScreen.java   ← Main cape list screen
│   ├── AddLocalCapeScreen.java ← Add local file cape
│   ├── AddOnlineCapeScreen.java← Add URL cape
│   └── CapeSettingsScreen.java ← Settings sliders/toggles
├── mixin/
│   ├── PlayerEntityRendererMixin.java ← Hooks into player rendering
│   └── GameRendererMixin.java         ← Reserved for future hooks
├── network/
│   └── CapeDownloader.java     ← HTTP download + disk caching
├── render/
│   ├── CapeRenderer.java       ← Physics-based smooth cape rendering
│   └── CapeRendererManager.java← Per-player renderer instances
└── util/
    └── CapeConfig.java         ← JSON config read/write
```

### Key Architecture Decisions

**Smooth animation:** Uses `System.currentTimeMillis()` for frame advancement — completely independent of TPS, so animation stays smooth even during lag.

**Physics sway:** Per-player `CapeRenderer` instances store momentum state (flap, side-sway, yaw lag) and use `MathHelper.lerp()` with `tickDelta` for sub-tick interpolation — same technique Lunar/Feather use.

**Offline support:** Online capes are stored in `capemaster/cache/<uuid>.png` on first download. On subsequent loads (or if network is unavailable), the cached file is used automatically.

**Texture registration:** Uses `NativeImageBackedTexture` registered with Minecraft's `TextureManager` under the `capemaster:cape/<id>_f<N>` namespace — no conflicts with vanilla or other mods.

---

## ❓ FAQ

**Q: Will this get me banned on servers?**  
A: No. CapeMaster is purely client-side visual — it sends no data to the server. No VAC-style anti-cheat can detect it.

**Q: Does it work with OptiFine / Iris?**  
A: It works with Iris + Sodium. OptiFine is incompatible with Fabric in general.

**Q: Can other players see my cape?**  
A: No — it's client-side only. Only you see your cape.

**Q: My online cape shows a broken texture / loading circle?**  
A: Wait 2–3 seconds after adding — the download is async. If it fails, check the URL is a direct `.png` link.

**Q: The animated cape plays too fast/slow?**  
A: Open the menu, delete the cape, re-add it with a different frame delay. 80ms ≈ 12fps, 50ms ≈ 20fps.

---

## 📄 License

MIT License — use, modify, distribute freely.

---

*Made with ❤️ for the Minecraft modding community. Inspired by Lunar Client & Feather Client cape systems.*
